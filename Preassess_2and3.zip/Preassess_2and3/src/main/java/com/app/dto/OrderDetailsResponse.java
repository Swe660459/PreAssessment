package com.app.dto;

import com.app.model.Order;
import com.app.model.Shipment;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OrderDetailsResponse {
    private Order order;
    private Shipment shipment;
}
