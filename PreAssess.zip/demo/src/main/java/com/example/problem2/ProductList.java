package com.example.problem2;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.RestContoller;
import org.springframework.web.bind.annotation.RestContoller;

@RestContoller
public class ProductList {
    @RequestMapping("sortProducts")
}
    public List<Product> productList(){
        List<Product> sortProducts = new ArrayList<>();

        Product p1=new Product();
        p1.setProductId("Prod3");
        p1.setProductName("Tie");
        p1.setUnitOfMeasure("EACH");
        p1.setLaunchDate("2021-02-24");

        Product p2=new Product();
        p2.setProductId("Prod3");
        p2.setProductName("Tie");
        p2.setUnitOfMeasure("EACH");
        p2.setLaunchDate("2021-02-22");

        Product p3=new Product();
        p3.setProductId("Prod2");
        p3.setProductName("Trousers");
        p3.setUnitOfMeasure("EACH");
        p3.setLaunchDate("2021-02-19");

        Product p4=new Product();
        p4.setProductId("Prod1");
        p4.setProductName("Shirt");
        p4.setUnitOfMeasure("EACH");
        p4.setLaunchDate("2021-02-21");

        sortProducts.add(p1);
        sortProducts.add(p2);
        sortProducts.add(p3);
        sortProducts.add(p4);

        return sortProducts;

}
