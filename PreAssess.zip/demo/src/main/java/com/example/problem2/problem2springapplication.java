package com.example.problem2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class problem2springapplication {

	public static void main(String[] args) {
		SpringApplication.run(problem2springapplication.class, args);

	}

}
