package com.example.demo;

public @interface RestContoller {
}
