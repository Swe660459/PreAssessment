package com.example.demo;
import  java.util.ArrayList;
import  java.util.List;

import org.springframework.web.bind.annotation.RestContoller;

@RestContoller
public class ProductList {
    @RequestMapping("createProduct")
    public List<Product> getProducts(){
      List<Product> createProduct = new ArrayList<>();

      Product p1=new Product();
      p1.setProductId("Prod1");
      p1.setProductName("Shirt");
      p1.setUnitOfMeasure("EACH");

      Product p2=new Product();
      p2.setProductId("Prod2");
      p2.setProductName("Trousers");
      p2.setUnitOfMeasure("EACH");

      Product p3=new Product();
      p3.setProductId("Prod3");
      p3.setProductName("Tie");
      p3.setUnitOfMeasure("EACH");

      createProduct.add(p1);
      createProduct.add(p2);
      createProduct.add(p3);

      return createProduct;



  }
}
